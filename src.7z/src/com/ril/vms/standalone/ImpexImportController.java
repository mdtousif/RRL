package com.ril.vms.standalone;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class ImpexImportController {
	// private static final int Map = 0;
	public static Workbook wb = null;
	private static String attribute = null;
	public static Workbook wb1 = null;

	public static void main(String[] args) throws IOException {

		ImpexImportController impcont = new ImpexImportController();

		/*
		 * Try to get it from args
		 * 
		 * From Path and To Path
		 */
		String filePath = "E:\\excelData.XLSM";

		File file = new File(filePath);
		System.out.println("1" + file);

		FileInputStream fis = new FileInputStream(file);
		System.out.println("2" + fis);

		try {
			wb = WorkbookFactory.create(fis);
		} catch (EncryptedDocumentException | InvalidFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// getting number of sheets and names
		System.out.println("sheet names");

		ImpexWriter impW = new ImpexWriter();
		int numberOfSheets = wb.getNumberOfSheets();
		// for (int i = 1; i < numberOfSheets; i++) {
		for (int i = 1; i < 8; i++) {
			String fileName = wb.getSheetAt(i).getSheetName();
			/*
			 * Remove below 2 lines
			 */
			impcont.getClassificationClassHeaderDetails(i, impcont);
			impcont.getAssignmentValues(i);

			impW.writeToFIle(i, fileName);
		}
		wb.close();
	}

	public List<String> getClassificationClass(int SheetNumber) {
		ArrayList<String> list = new ArrayList<String>();
		String sheetName = wb.getSheetAt(SheetNumber).getSheetName();
		GenericUtil grMeth = new GenericUtil();
		List<String> splitName = grMeth.splitSheetName(sheetName);
		String NamePrefix = splitName.get(1);

		System.out.println(NamePrefix);
		String catName = splitName.get(0);
		System.out.println(catName);
		list.add(catName);
		System.out.println("Sheet Name " + catName + " Prefix " + NamePrefix);
		int l2CategoryCellNumber = 2;
		int l3CategoryCellNumber = 4;
		int l4CategoryCellNumber = 6;
		if (NamePrefix.equalsIgnoreCase("L2")) {

			for (int i = 0; i < wb1.getSheetAt(0).getLastRowNum(); i++) {
				String cellvalue = wb1.getSheetAt(0).getRow(i).getCell(l2CategoryCellNumber).getStringCellValue();
				if (catName.equalsIgnoreCase(cellvalue)) {

					String code = wb1.getSheetAt(0).getRow(i).getCell(l2CategoryCellNumber + 1).toString();
					String[] code1 = grMeth.splitAtDecimal(code);
					System.out.println("L2 nmnm,nm,nm,nmnm,code  " + code1[0]);
					list.add(code1[0]);
					break;
				}
			}
		} else if (NamePrefix.equalsIgnoreCase("L3")) {

			for (int i = 0; i < wb1.getSheetAt(0).getLastRowNum(); i++) {
				String cellvalue = wb1.getSheetAt(0).getRow(i).getCell(l3CategoryCellNumber).getStringCellValue();
				if (catName.equalsIgnoreCase(cellvalue)) {

					String code = wb1.getSheetAt(0).getRow(i).getCell(l3CategoryCellNumber + 1).toString();
					String[] code1 = grMeth.splitAtDecimal(code);
					System.out.println("L4 mlmlmlmmmm,m,m,m,m,code  " + code1[0]);
					list.add(code1[0]);
					break;
				}
			}
		}

		else if (NamePrefix.equalsIgnoreCase("L4")) {

			for (int i = 0; i < wb1.getSheetAt(0).getLastRowNum(); i++) {
				String cellvalue = wb1.getSheetAt(0).getRow(i).getCell(l4CategoryCellNumber).getStringCellValue();
				if (catName.equalsIgnoreCase(cellvalue)) {

					String code = wb1.getSheetAt(0).getRow(i).getCell(l4CategoryCellNumber + 1).toString();
					String[] code1 = grMeth.splitAtDecimal(code);
					System.out.println("L4 code  " + code1[0]);
					list.add(code1[0]);
					break;
				}
			}
		}
		System.out.println(list);
		return list;
	}

	public Map<String, List<String>> getCoulmnValues(int sheetNumber) {
		int columnNumber = 0;

		Sheet sheet = wb.getSheetAt(sheetNumber);
		Map<String, List<String>> map = new HashMap<>();
		for (int j = 2; j <= sheet.getLastRowNum(); j++) {

			int x = sheet.getRow(j).getLastCellNum();
			int y=sheet.getPhysicalNumberOfRows();
			System.out.println("getPhysicalNumberOfRows()   "+y);
			attribute = sheet.getRow(j).getCell(0).getStringCellValue();
			if (!sheet.getRow(j).getCell(x - 1).getStringCellValue().isEmpty()) {

				String listOfValue = sheet.getRow(j).getCell(x - 1).getStringCellValue();

				System.out.println(attribute + "  " + listOfValue);

				Sheet listOfValueSheet = wb.getSheetAt(0);

				int lastcellnum = listOfValueSheet.getRow(0).getLastCellNum();
				for (int k = 0; k < lastcellnum; k++) {
					boolean column = listOfValueSheet.getRow(0).getCell(k).getStringCellValue().trim()
							.equals(listOfValue);
					if (column) {
						columnNumber = k;
						String cells = null;
						ArrayList<String> list = new ArrayList<String>();
						for (int i = 1; i <= listOfValueSheet.getLastRowNum(); i++) {
							if (listOfValueSheet.getRow(i).getCell(columnNumber) != null) {
								cells = listOfValueSheet.getRow(i).getCell(columnNumber).toString();

								list.add(cells);

								map.put(attribute, list);

							}

						}
						// System.out.println(map);
						// System.out.println();

					}

				}
				System.out.println("New Map " + map);

			} else {
				// map.putIfAbsent(attribute, null);
				map.put(attribute, null);
			}

		}
		// System.out.println(map);
		return map;

	}

	public void getClassificationClassHeaderDetails(int sheetNumber, ImpexImportController impcont) throws IOException {
		String filePath = "E:\\Categories with codes.xlsx";

		File file = new File(filePath);
		FileInputStream fis = new FileInputStream(file);

		try {
			wb1 = WorkbookFactory.create(fis);
		} catch (EncryptedDocumentException | InvalidFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("NUmber sheets in second excel " + wb.getNumberOfSheets());

		impcont.getClassificationClass(sheetNumber);

		wb1.close();
	}

	// method to read assignment values
	public Map<String, List<String>> getAssignmentValues(int sheetNumber) {
		HashMap<String, List<String>> assignmentValuesMap = new HashMap<>();
		Sheet catSheetValues = wb.getSheetAt(sheetNumber);
		for (int i = 2; i <= catSheetValues.getLastRowNum(); i++) {
			System.out.println("Last row " + catSheetValues.getLastRowNum());
			System.out.println("Last row physical sheet "+catSheetValues.getPhysicalNumberOfRows());
			ArrayList<String> assigValues = new ArrayList<String>();
			attribute = catSheetValues.getRow(i).getCell(0).getStringCellValue();
			for (int j = 0; j < catSheetValues.getRow(i).getLastCellNum(); j++) {

				// String a = catSheetValues.getRow(i).getCell(j).getStringCellValue();
				switch (j) {

				case 2:
					String MandCell = catSheetValues.getRow(i).getCell(j).getStringCellValue();
					if (MandCell.equalsIgnoreCase("Y"))
						assigValues.add("TRUE");
					else
						assigValues.add("FALSE");

					// System.out.println(assigValues);
					break;

				case 3:
					String venderOpcell = catSheetValues.getRow(i).getCell(j).getStringCellValue();
					if (venderOpcell.equalsIgnoreCase("V"))
						assigValues.add("TRUE");
					else
						assigValues.add("FALSE");
					break;
				// System.out.println(assigValues);

				/*
				 * case 4: String dropOrFreeTextCell =
				 * catSheetValues.getRow(i).getCell(j).getStringCellValue(); if
				 * (dropOrFreeTextCell.equalsIgnoreCase("D")) assigValues.add("TRUE"); else if
				 * (dropOrFreeTextCell.equalsIgnoreCase("F")) assigValues.add("FALSE");
				 * 
				 * // System.out.println(assigValues);
				 * 
				 * break;
				 */

				case 5:
					String multiValueCell = catSheetValues.getRow(i).getCell(j).getStringCellValue();
					if (multiValueCell.equalsIgnoreCase("M"))
						assigValues.add("TRUE");
					else if (multiValueCell.equalsIgnoreCase("S"))
						assigValues.add("FALSE");

					// System.out.println(assigValues);

					break;

				case 6:
					String facetableCell = catSheetValues.getRow(i).getCell(j).getStringCellValue();
					if (facetableCell.equalsIgnoreCase("Y"))
						assigValues.add("TRUE");
					else
						assigValues.add("FALSE");

					// System.out.println(assigValues);

					break;

				case 7:
					String searchebleCell = catSheetValues.getRow(i).getCell(j).getStringCellValue();
					if (searchebleCell.equalsIgnoreCase("Y"))
						assigValues.add("TRUE");
					else
						assigValues.add("FALSE");

					// System.out.println(assigValues);

					break;

				case 8:
					String displayableCell = catSheetValues.getRow(i).getCell(j).getStringCellValue();
					if (displayableCell.equalsIgnoreCase("Y"))
						assigValues.add("TRUE");
					else
						assigValues.add("FALSE");

					// System.out.println(assigValues);

					break;

				case 9:
					String sortableCell = catSheetValues.getRow(i).getCell(j).getStringCellValue();
					if (sortableCell.equalsIgnoreCase("Y"))
						assigValues.add("TRUE");
					else
						assigValues.add("FALSE");

					// System.out.println(assigValues);

					break;
				}
			}
			assignmentValuesMap.put(attribute, assigValues);
			System.out.println(assignmentValuesMap);

		}

		System.out.println();

		return assignmentValuesMap;

	}

	public Map<String, String> getDropDownAssignmentValues(int sheetNumber) {

		Map<String, String> dropDownList = new HashMap<String, String>();
		Sheet catSheetValues = wb.getSheetAt(sheetNumber);
		for (int i = 2; i <= catSheetValues.getLastRowNum(); i++) {

			attribute = catSheetValues.getRow(i).getCell(0).getStringCellValue();
			String val = catSheetValues.getRow(i).getCell(4).getStringCellValue();
			if (val.equalsIgnoreCase("D")) {
				dropDownList.put(attribute, "enum:ClassificationAttributeTypeEnum;");
			} else if (val.equalsIgnoreCase("F")) {
				dropDownList.put(attribute, ";");
			}

		}
		System.out.println("Drop Down List" + dropDownList);
		return dropDownList;

	}
}