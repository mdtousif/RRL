package com.ril.vms.standalone;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

public class GenericUtil {
	String folderName;
	String SEPARATOR_SPACE = ".";

	public List<String> splitSheetName(String sheetName) {
		List<String> splittedName = new ArrayList<>();
		String[] parts = sheetName.split("-");
		String part1 = parts[0];
		String part2 = parts[1];
		splittedName.add(part2);
		splittedName.add(part1);
		return splittedName;

	}

	public String[] splitAtDecimal(final String name) {
		String trimmed = StringUtils.trimToNull(name);
		return new String[] { StringUtils.substringBeforeLast(trimmed, SEPARATOR_SPACE),
				StringUtils.substringAfterLast(trimmed, SEPARATOR_SPACE) };
	}

	public String getFolderStructBasedOnCategoryLevel(String sheetName) {
		GenericUtil genericUtils = new GenericUtil();
		List<String> splitName = genericUtils.splitSheetName(sheetName);

		String NamePrefix = splitName.get(1);
		System.out.println("From impex writter " + NamePrefix);
		String catName = splitName.get(0);
		System.out.println(catName);
		if (NamePrefix.equalsIgnoreCase("L2")) {

			folderName = "E:\\Impex/L2Category/";

		} else if (NamePrefix.equalsIgnoreCase("L3")) {
			folderName = "E:\\Impex/L3Category/";

		} else if (NamePrefix.equalsIgnoreCase("L4")) {
			folderName = "E:\\Impex/L4Category/";

		}

		return folderName;

	}

}