package com.ril.vms.standalone;

public class Test 
{
	public static void main(String[] args)
	{
		try
		{
			//code
			func1();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	private static void func1()throws Exception
	{
		int x =1/0;
	}
}
