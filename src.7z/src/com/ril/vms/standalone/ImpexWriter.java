package com.ril.vms.standalone;

import java.io.BufferedWriter;
import java.io.File;

import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class ImpexWriter {

	ImpexImportController impcont = new ImpexImportController();

	public void writeToFIle(int sheetNumber1, String fileName) throws IOException {
		int sheetNumber = sheetNumber1;
		// Create file system using specific name

		GenericUtil genericUtils = new GenericUtil();
		String path = genericUtils.getFolderStructBasedOnCategoryLevel(fileName);
		// System.out.println("path " + path);

		System.out.println("Writting impex for " + fileName);
		File file = new File(path);
		try {

			file.mkdir();
			file = new File(path + "/" + fileName);
			file.createNewFile();

			// creates a FileWriter Object
			FileWriter writer = new FileWriter(file);

			BufferedWriter bw = new BufferedWriter(writer);

			// Writes the content to the file
			bw.write(ImpexHeaders.macros_Header);
			bw.newLine();
			bw.newLine();
			bw.write(ImpexHeaders.ClassificationClass_Header);
			List<String> catNameCode = impcont.getClassificationClass(sheetNumber);
			System.out.println("catNameCode catNameCode catNameCodecatNameCode " + catNameCode);
			bw.newLine();
			bw.write(";" + catNameCode.get(1) + "CC;" + catNameCode.get(0) + "CC;;;"
					+ "B2B:MarketplaceType;customergroup");
			System.out.println("catNameCodedvjkbsjkdbvskdjbvsjkdbvsjdbjkvsbndkjvkjs  " + catNameCode.get(0));
			bw.newLine();
			bw.newLine();
			bw.write(ImpexHeaders.CategoryCategoryRelation_Header);
			bw.newLine();
			bw.write(";" + catNameCode.get(1) + "CC;" + catNameCode.get(1) + ";");
			bw.newLine();
			bw.newLine();
			bw.write(ImpexHeaders.ClassificationAttribute_Header);
			bw.newLine();
			Map<String, List<String>> attributes = impcont.getCoulmnValues(sheetNumber);

			Set<String> keys = attributes.keySet();
			for (String key : keys) {
				bw.write(";" + key + ";" + key);

				bw.newLine();

			}
			bw.newLine();
			bw.newLine();
			bw.write(ImpexHeaders.ClassificationAttributeValue_Header);
			bw.newLine();
			for (Map.Entry<String, List<String>> entry : attributes.entrySet()) {
				// String key = entry.getKey();
				List<String> values = entry.getValue();
				if (entry.getValue() != null) {
					for (String value : values) {

						bw.write(";" + value + ";" + value);
						bw.newLine();
					}
					bw.newLine();
					bw.newLine();
				}
			}

			bw.write(ImpexHeaders.ClassAttributeAssignment_Header);
			bw.newLine();
			// bw.write(";" + catNameCode.get(1) + "CC;");
			// Writing attributes
			Map<String, String> dropDown = impcont.getDropDownAssignmentValues(sheetNumber);
			// System.out.println("Drop Down List "+dropDown);

			Set<String> key1 = attributes.keySet();

			for (String key : key1) {
				bw.write(";" + catNameCode.get(1) + "CC;");
				bw.write(key + ";;");
				// Writing values
				for (Entry<String, String> entry : dropDown.entrySet()) {
					if (key.equalsIgnoreCase(entry.getKey())) {
						bw.write(entry.getValue());
						System.out.println("True values " + entry.getValue());
					}

				}

				for (Map.Entry<String, List<String>> entry : attributes.entrySet()) {
					// String key = entry.getKey();

					List<String> values = entry.getValue();
					if (key.equalsIgnoreCase(entry.getKey())) {
						List<String> a = entry.getValue();

						int count = 1;
						if (entry.getValue() != null) {
							for (String value : values) {
								bw.write(value);
								if (count < a.size()) {
									bw.write(",");
								}
								count++;
							}
						}

					}

				}
				bw.write(";");
				Map<String, List<String>> assignedAttributesval = impcont.getAssignmentValues(sheetNumber);
				for (Map.Entry<String, List<String>> entry : assignedAttributesval.entrySet()) {
					// String key = entry.getKey();

					List<String> values = entry.getValue();
					if (key.equalsIgnoreCase(entry.getKey())) {
						List<String> a = entry.getValue();

						int count = 1;
						for (String value : values) {
							bw.write(value);
							if (count < a.size()) {
								bw.write(";");
							}
							count++;
						}

					}

				}
				bw.newLine();
			}

			bw.flush();
			bw.close();
		} catch (Exception e) {
			System.out.println(e);

		}
	}

}
