package com.ril.vms.standalone;

public class ImpexHeaders {

	public static final String macros_Header = "# Macros / Replacement Parameter definitions\r\n"
			+ "$masterProductCatalog=vmsProductCatalog\r\n"
			+ "$classCatalogVersion=catalogversion(catalog(id[default=vmsClassification]),version[default=1.0])[unique=true,default=vmsClassification:1.0]\r\n"
			+ "$catalogVersion=catalogversion(catalog(id[default=vmsProductCatalog]),version[default=Staged])[unique=true,default=vmsProductCatalog:Staged]\r\n"
			+ "$classSystemVersion=systemVersion(catalog(id[default=vmsClassification]),version[default=1.0])[unique=true]\r\n"
			+ "$class=classificationClass(ClassificationClass.code,$classCatalogVersion)[unique=true]\r\n"
			+ "$attribute=classificationAttribute(code,$classSystemVersion)[unique=true]\r\n" + "# Language\r\n"
			+ "$lang=en";

	public static final String ClassificationClass_Header = "INSERT_UPDATE ClassificationClass;code[unique=true];name[lang=$lang];$classCatalogVersion;categoryType[default=Root];marketPlaceType(code,itemtype(code));allowedPrincipals(uid)";

	public static final String CategoryCategoryRelation_Header = "INSERT_UPDATE CategoryCategoryRelation;source(code,$classCatalogVersion)[unique=true];target(code,$catalogVersion)[unique=true]";

	public static final String ClassificationAttribute_Header = "INSERT_UPDATE ClassificationAttribute;code[unique=true];name[lang=$lang];externalID;$classSystemVersion";

	public static final String ClassificationAttributeValue_Header = "INSERT_UPDATE ClassificationAttributeValue;code[unique=true]; name[lang=$lang];$classSystemVersion";

	public static final String ClassAttributeAssignment_Header = "INSERT_UPDATE ClassAttributeAssignment;$class;$attribute;description[lang=$lang];attributeType(code,itemtype(code))[default=string:ClassificationAttributeTypeEnum];attributeValues(code,$classSystemVersion);mandatory[default=false];vendorInput[default=true];multiValued[default=false];facetable[default=false];searchable[default=false];displayable[default=false];sortable[default=false]";

}
